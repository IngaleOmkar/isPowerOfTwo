# isPowerOfTwo
This is a python package to check if a given number is a power of 2.

This is done as follows:
1. Convert given number to binary.
2. Find the logical AND of the number and (number - 1)
3. If the result of previous step is 0, the number is a power.

This package will be published to PyPI.
